package com.example.moacir;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
    }
    public void brasil(View v){
        Intent c = new Intent(this, Brasil.class);
        startActivity(c);
    }
    public void russia(View v){
        Intent c = new Intent(this, Russia.class);
        startActivity(c);
    }
    public void ucrania(View v){
        Intent c = new Intent(this, Ucrania.class);
        startActivity(c);
    }
    public void china(View v){
        Intent c = new Intent(this, Chona.class);
        startActivity(c);
    }
}